//BootProj03MiniProjectDIApplication.java(08/10/11.02.2025)
package com.nt;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.nt.controller.PayrollOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public class BootProj031MiniProjectDIApplication1 {

	public static void main(String[] args) {
		try(//get access to IOC container
		ConfigurableApplicationContext ctx=SpringApplication.run(BootProj031MiniProjectDIApplication1.class, args);
				
		//get Scanner class object
		Scanner sc=new Scanner(System.in);
		){
			
		//get Controller class object reference
		PayrollOperationsController controller=ctx.getBean("payroll",PayrollOperationsController.class);
		//read inputs from the end user
		System.out.println("Enter Degs1::");
		String degs1=sc.next();
		
		System.out.println("Enter Degs2::");
		String degs2=sc.next();
		
		System.out.println("Enter Degs3::");
		String degs3=sc.next();
		
		//invoke the business method
			List<Employee> list=controller.showAllEmployeesByDegs(degs1,degs2, degs3);
			//process the results
			System.out.println("Employees belonging to "+degs1+" "+degs2+" "+degs3+"  are ");
			list.forEach(emp->{
				System.out.println(emp);
			     });
		}//try
		catch(Exception e) {
			System.out.println("Internal Problem::"+e.getMessage());
			e.printStackTrace();
		}
	}//main
}//class
