//BootProj03MiniProjectDIApplication.java(08/10/11.02.2025)
package com.nt;

import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.ApplicationContext;

import com.nt.controller.PayrollOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public class BootProj031MiniProjectDIApplication {

	public static void main(String[] args) {
		//get IOC container
		ApplicationContext ctx=SpringApplication.run(BootProj031MiniProjectDIApplication.class, args);
		//get Controller class object reference
		PayrollOperationsController controller=
				ctx.getBean("payroll",PayrollOperationsController.class);
		//invoke the business method
		try {
			List<Employee> list=controller.showAllEmployeesByDegs("CLERK","MANAGER", "SALESMAN");
			//process the results
			list.forEach(emp->{
				System.out.println(emp);
			     });
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}//close the container
		((ConfigurableApplicationContext)ctx).close();
	}//main
}//class
