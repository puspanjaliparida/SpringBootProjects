//PayrollOperationsController.java(08/10/11/12.02.2025)
package com.nt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nt.model.Employee;
import com.nt.service.IEmployeeService;

@Controller("payroll")
public class PayrollOperationsController {
         
	@Autowired
	private IEmployeeService service;
	
	//for retrieving record
	public List<Employee> showAllEmployeesByDegs(String degs1,String degs2,String degs3) throws Exception{
		//use service
		List<Employee> list=service.fetchAllEmployeesByDegs(degs1,degs2,degs3);
		return list;
	}
	
	//for inserting record
	public String processEmployeeInsert(Employee emp)throws Exception{
		//use service
		String resultMsg=service.registerEmployee(emp);
		return resultMsg;
	}
	
	//for updating record
	public String processEmployeeUpdate(Employee emp) throws Exception {
	    //use service
	    String resultMsg = service.modifyEmployee(emp);
	    return resultMsg;
	}
	
	//for deleting record
	public String processEmployeeDelete(int eno)throws Exception{
		//use service
		String resultMsg = service.removeEmployee(eno);
		return resultMsg;
	}
}//class
