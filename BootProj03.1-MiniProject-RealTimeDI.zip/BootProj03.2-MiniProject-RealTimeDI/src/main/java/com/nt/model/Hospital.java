//Employee.java(12.02.2025)
package com.nt.model;

import lombok.Data;

@Data
public class Hospital {
          private Integer hospitalid;
          private String hospitalname;
          private String location;
          private Double phonenumber;
          private Integer establishedyear;
}
